<?php 
/*
Plugin Name: SM Facebook Comments
Plugin URI: http://www.mahabub.me
Author: Mahabubur Rahman
*/

require 'includes/sm-fb-comments-admin.php';
require 'includes/sm-facebook-comments-shortcode.php';


// Add settings link on plugin page
function sm_facebook_settings_link($links) {
  $settings_link = '<a href="options-general.php?page=smfbcomments">Settings</a>';
  array_unshift($links, $settings_link);
  return $links;
}

$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'sm_facebook_settings_link' );


